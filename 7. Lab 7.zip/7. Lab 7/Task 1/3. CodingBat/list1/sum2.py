def sum2(a):
    if(len(a)>=2):
        return a[0]+a[1]
    elif(len(a)==1):return a[0]
    else :return 0