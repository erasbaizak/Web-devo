def sum3(a):
    return a[0]+a[1]+a[2]
