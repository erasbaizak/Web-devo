def makes10(a,b):
    if a== 10 or 10 ==b or a+b==10:
        return True
    return False
