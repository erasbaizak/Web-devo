def without_end(s):
    return s[1:-1]
s = input()
print(without_end(s))