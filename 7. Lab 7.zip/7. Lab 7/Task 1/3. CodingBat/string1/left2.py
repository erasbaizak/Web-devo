def left2(s):
    return s[2:]+s[:2]
s= input()
print(left2(s))