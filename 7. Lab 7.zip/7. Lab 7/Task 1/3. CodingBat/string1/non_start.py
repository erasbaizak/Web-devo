def non_start(a,b):
    return a[1:]+b[1:]
s = input()
t = input()
print(non_start(s,t))