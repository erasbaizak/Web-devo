def hello(s):
    return "Hello "+s
s = input()
print(hello(s))
