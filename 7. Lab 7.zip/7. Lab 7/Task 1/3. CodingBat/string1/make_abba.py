def make_abba(s,t):
    return s+t+t+s
s  = input()
t = input()
print(make_abba(s,t))