def first_two(s):
    if(len(s)<=2):return s
    else : return s[:2]
s = input()
print(first_two(s))