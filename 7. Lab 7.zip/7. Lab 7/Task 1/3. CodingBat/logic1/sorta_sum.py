def sum(a,b):
    if(10 <= a+b <=21):
        return 20
    return a+b