def cigar(num,isweek):
    if(40<= num <=60 or isweek==True):return True
    return False