velocity = int(input())
time = int(input())

print((velocity * time) % 109)