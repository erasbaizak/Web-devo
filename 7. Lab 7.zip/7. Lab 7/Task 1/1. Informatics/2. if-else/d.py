x = float(input())

if x > 0:
    sign_x = 1
elif x < 0:
    sign_x = -1
else:
    sign_x = 0

print(sign_x)
