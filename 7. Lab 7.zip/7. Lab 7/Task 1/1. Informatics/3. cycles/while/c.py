x = int(input())
num = 1

while x > num:
    print(num, end=" ")
    num *= 2
