n = int(input())
sum_of_n = 0

for i in range(n):
    sum_of_n += int(input())

print(sum_of_n)
