a = str(input())
sum_of_a = 0

for i in a:
    sum_of_a += int(i)
    
print(sum_of_a)
