a = int(input())
b = int(input())
print(f'{a+b}\n{a-b}\n{a*b}')